import React, {useEffect, useState} from 'react';
import {SafeAreaView, View, Text, Pressable, StyleSheet, ScrollView, TextInput, Alert} from 'react-native';
import AsyncStorage from '@react-native-async-storage/async-storage';
import * as Notifications from 'expo-notifications';

const MEALS=[['breakfast','Breakfast','🍳','08:00'],['snack','Snack','🍎','11:00'],['lunch','Lunch','🥗','13:00'],['dinner','Dinner','🍲','19:00']];
const KEY='norish-meals';
Notifications.setNotificationHandler({handleNotification:async()=>({shouldShowBanner:true,shouldShowList:true,shouldPlaySound:true})});

export default function App(){
 const [meals,setMeals]=useState({}); const [name,setName]=useState('My Love'); const [tab,setTab]=useState('today');
 useEffect(()=>{(async()=>{const raw=await AsyncStorage.getItem(KEY); if(raw)setMeals(JSON.parse(raw)); await Notifications.requestPermissionsAsync();})()},[]);
 const today=new Date().toISOString().slice(0,10);
 const setEaten=async(id)=>{const next={...meals,[`${today}-${id}`]:true};setMeals(next);await AsyncStorage.setItem(KEY,JSON.stringify(next));};
 const schedule=async()=>{for(const [id,label,emoji,time] of MEALS){const [h,m]=time.split(':').map(Number);await Notifications.scheduleNotificationAsync({content:{title:`Norish 💗`,body:`Hey ${name}, it’s time for ${label.toLowerCase()} ${emoji}`},trigger:{type:Notifications.SchedulableTriggerInputTypes.DAILY,hour:h,minute:m}})}Alert.alert('Reminders set','Norish will remind you every day.');};
 const done=MEALS.filter(x=>meals[`${today}-${x[0]}`]).length;
 return <SafeAreaView style={s.safe}><ScrollView contentContainerStyle={s.container}>
  <View style={s.header}><View><Text style={s.brand}>norish</Text><Text style={s.sub}>little reminders, lots of care 💗</Text></View><Text style={s.heart}>♡</Text></View>
  {tab==='today'?<>
   <View style={s.hero}><Text style={s.hello}>Hi, {name} 💕</Text><Text style={s.heroText}>Let’s make today a nourished day.</Text><View style={s.progress}><View style={[s.progressFill,{width:`${done/MEALS.length*100}%`}]}/></View><Text style={s.progressText}>{done} of {MEALS.length} checked in</Text></View>
   <Text style={s.title}>Today’s meals</Text>
   {MEALS.map(([id,label,emoji,time])=>{const eaten=!!meals[`${today}-${id}`];return <View key={id} style={s.card}><Text style={s.emoji}>{emoji}</Text><View style={{flex:1}}><Text style={s.label}>{label}</Text><Text style={s.time}>{time}</Text></View><Pressable onPress={()=>setEaten(id)} style={[s.button,eaten&&s.buttonDone]}><Text style={s.buttonText}>{eaten?'✓ Ate':'I Ate'}</Text></Pressable></View>})}
   <Pressable style={s.reminder} onPress={schedule}><Text style={s.reminderText}>🔔 Set daily reminders</Text></Pressable>
  </>:<View><Text style={s.title}>Settings</Text><Text style={s.settingLabel}>Name</Text><TextInput value={name} onChangeText={setName} style={s.input} placeholder="Your name"/><Text style={s.note}>Norish works offline. Your check-ins are saved on this phone. Online partner syncing can be connected through Firebase once you add your project settings.</Text></View>}
  <View style={s.nav}><Pressable onPress={()=>setTab('today')}><Text style={[s.navText,tab==='today'&&s.navActive]}>Today</Text></Pressable><Pressable onPress={()=>setTab('settings')}><Text style={[s.navText,tab==='settings'&&s.navActive]}>Settings</Text></Pressable></View>
 </ScrollView></SafeAreaView>
}
const s=StyleSheet.create({safe:{flex:1,backgroundColor:'#f8f8ff'},container:{padding:22,paddingBottom:100},header:{flexDirection:'row',justifyContent:'space-between',alignItems:'center',marginBottom:24},brand:{fontSize:36,fontWeight:'800',color:'#5969d8'},sub:{color:'#8b8fa8',marginTop:2},heart:{fontSize:42,color:'#ee78a7'},hero:{backgroundColor:'#eef0ff',borderRadius:26,padding:20,marginBottom:24},hello:{fontSize:23,fontWeight:'800',color:'#454d9b'},heroText:{fontSize:15,color:'#6e7290',marginTop:5},progress:{height:9,backgroundColor:'#fff',borderRadius:8,marginTop:18,overflow:'hidden'},progressFill:{height:9,backgroundColor:'#e978aa',borderRadius:8},progressText:{color:'#7a7e99',fontSize:12,marginTop:8},title:{fontSize:22,fontWeight:'800',color:'#30344f',marginBottom:14},card:{backgroundColor:'#fff',borderRadius:20,padding:15,marginBottom:12,flexDirection:'row',alignItems:'center',shadowColor:'#7b7da0',shadowOpacity:.08,shadowRadius:8,elevation:2},emoji:{fontSize:30,marginRight:13},label:{fontSize:17,fontWeight:'700',color:'#343852'},time:{fontSize:13,color:'#9295aa',marginTop:3},button:{backgroundColor:'#5969d8',paddingHorizontal:15,paddingVertical:10,borderRadius:14},buttonDone:{backgroundColor:'#e978aa'},buttonText:{color:'#fff',fontWeight:'800'},reminder:{backgroundColor:'#fff0f7',padding:16,borderRadius:18,alignItems:'center',marginTop:6},reminderText:{color:'#c34f82',fontWeight:'800'},nav:{position:'absolute',bottom:10,left:22,right:22,backgroundColor:'#fff',borderRadius:22,padding:15,flexDirection:'row',justifyContent:'space-around',elevation:5},navText:{color:'#9699ad',fontWeight:'700'},navActive:{color:'#5969d8'},settingLabel:{fontWeight:'700',color:'#555a76',marginBottom:8},input:{backgroundColor:'#fff',borderRadius:15,padding:14,fontSize:16,marginBottom:20},note:{color:'#777b92',lineHeight:22}}
);
