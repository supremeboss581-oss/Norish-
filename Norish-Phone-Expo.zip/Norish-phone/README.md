# Norish — phone-only Android build

This is an Expo/React Native version designed for a phone-first workflow. It saves meal check-ins offline and schedules daily notifications. The Firebase sync layer can be added by putting your Firebase config into the app; the UI is intentionally ready for that next step.

## Build the APK from your phone
1. Create a free Expo account at https://expo.dev/.
2. Create a GitHub repository from these files (GitHub's website works in a mobile browser).
3. Open GitHub Codespaces for the repository from your phone.
4. In the Codespace terminal run:
   `npm install`
   `npx eas login`
   `npx eas build:configure`
   `npx eas build --platform android --profile preview`
5. Expo/EAS will give you a build page. Open it on your phone and download/install the APK.

## Test without building
Install Expo Go on the Android phone, then run `npm install` and `npx expo start` in Codespaces. Scan/open the Expo project from Expo Go.

## Online syncing
The current project is offline-first. To enable two-phone syncing, create a Firebase project, enable Authentication and Firestore, then add the Firebase web configuration and a partner-link flow. Do not put private server credentials in the app.
